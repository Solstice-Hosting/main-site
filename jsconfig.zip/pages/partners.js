import Header from "@/components/main/Header";
import Head from "next/head";

export default function PartnerPage() {
    return (
        <>
            <Head>
                <title>Partners - SolsticeHosting</title>
                <meta name="description" content="Our wonderful partners; quite literally the friends we've made along the way." />
                <meta name="keywords" content="partners, minecraft hosting, hosting, hosting partners, solstice hosting, solstice partner, partner with solstice" />
            </Head>
            <Header />

        </>
    )
}